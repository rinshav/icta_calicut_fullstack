
def empdata():

	empdata = [
		
		{
			'id':1,
			'name':'a',
			'title':'dev'
	
	
		},
	
		{
			'id':2,
			'name':'b',
			'title':'test'
	
	
		},
	
		{
			'id':3,
			'name':'c',
			'title':'lead'
	
	
		},
	
		{
			'id':4,
			'name':'d',
			'title':'hr'
	
	
		},
	
		{
			'id':1,
			'name':'e',
			'title':'arch'
	
	
		}
	
	
	]	
	return empdata
